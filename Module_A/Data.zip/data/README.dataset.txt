# Пятерочка Ценники > 2024-06-15 7:40pm
https://universe.roboflow.com/project-xjsry/-mxpf6

Provided by a Roboflow user
License: CC BY 4.0

